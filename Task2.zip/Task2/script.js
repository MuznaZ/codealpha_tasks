document.addEventListener('DOMContentLoaded', function() {
    const display = document.querySelector('.calculator input[type="text"]');
    const buttons = document.querySelectorAll('.calculator button');
    let currentInput = '';
    let operator = null;
    let previousInput = '';

    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const value = this.textContent.trim();

            if (!isNaN(value) || value === '.') {
                // Append number or decimal to current input
                currentInput += value;
                display.value = currentInput;
            } else if (value === 'AC') {
                // Clear everything
                currentInput = '';
                previousInput = '';
                operator = null;
                display.value = '0';
            } else if (value === 'DEL') {
                // Delete the last character
                currentInput = currentInput.slice(0, -1);
                display.value = currentInput || '0';
            } else if (value === '=') {
                // Calculate result
                if (operator && previousInput) {
                    currentInput = evaluate(previousInput, operator, currentInput);
                    display.value = currentInput;
                    operator = null;
                    previousInput = '';
                }
            } else {
                // Handle operators
                if (currentInput && !operator) {
                    operator = value;
                    previousInput = currentInput;
                    currentInput = '';
                } else if (currentInput && operator) {
                    currentInput = evaluate(previousInput, operator, currentInput);
                    display.value = currentInput;
                    operator = value;
                    previousInput = currentInput;
                    currentInput = '';
                }
            }
        });
    });

    function evaluate(a, operator, b) {
        let result = 0;
        a = parseFloat(a);
        b = parseFloat(b);

        switch (operator) {
            case '+':
                result = a + b;
                break;
            case '-':
                result = a - b;
                break;
            case '*':
                result = a * b;
                break;
            case '/':
                result = a / b;
                break;
            case '%':
                result = a % b;
                break;
        }

        return result.toString();
    }
});
